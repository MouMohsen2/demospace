<?php include '../includes/navbar.php';?>

<body>

<div class="content">
<?php include 'login.php';?>
<?php include 'signup.php';?>
</div>

</body>
</html>
<?php ob_end_flush(); ?>
