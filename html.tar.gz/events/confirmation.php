<html>
  <?php include '../includes/navbar.php' ?>
  <div class="content">
    <div class="text-center col-md-6 col-md-offset-3" style="margin-top:10%;">
      <h1 class="text-success">Booking Done</h1>
      <h2>Our team will contant you soon</h2>
      <hr></hr>
      <h2>What about <a href="../posts">checking our blog?</a></h2>
    </div>
  </div>
</html>
