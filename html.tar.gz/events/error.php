<html>
<?php include '../includes/navbar.php' ?>
  <div class="content">
    <div class="text-center col-md-6 col-md-offset-3" style="margin-top:10%;">
      <h1 class="text-danger">Sorry !!</h1>
      <h2>We are out of tickets for this event</h2>
      <hr></hr>
      <h2>What about <a href="../posts">checking our blog?</a></h2>
    </div>
  </div>
</html>
